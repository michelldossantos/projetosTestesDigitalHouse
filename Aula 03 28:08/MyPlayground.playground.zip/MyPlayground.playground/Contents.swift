import UIKit

var name: String = "X"




let pi:Float = 3.1315

let qualquerCoisa = 123
//
//
if qualquerCoisa == 123 {
    print("é igual")
} else {
    print("não é igual")
}
//
//let entendi = true
//
//if entendi == true {
//    print("Entendi")
//} else {
//    print("Não entendi")
//}
//
//
//
//func digaOla() {
//    print("Olá")
//}
//
//digaOla()
//
//func entendeu() -> Bool {
//    return true
//}
//
//func myPrint(message: String) {
//    print("\(Date()) - Narlei - \(message)")
//}
//
//
//myPrint(message: "Olá galera")
//
//
//
//func nota(aluno: String) -> Int {
//    if aluno == "Narlei" {
//        return 5
//    } else {
//        return 10
//    }
//}
//
//
//let minhaNota = nota(aluno: "Narlei")
//myPrint(message: "\(minhaNota)")
//
//
//
//func cumprimentarA(pessoa: String) {
//    print("Iae \(pessoa)")
//}
//
//cumprimentarA(pessoa: "João")
//
//
//func cumprimentar(nome pessoa: String) {
//    print("Olá \(pessoa)")
//}
//cumprimentar(nome: "João")
//
//
//
//func cumprimentarX(_ pessoa: String) {
//    print("Bom dia \(pessoa)")
//}
//
//
//cumprimentarX("João")
//
//
//
//
//
//func eMenor(oPrimeiro: Int, oSegundo:Int) -> Bool {
//    if oPrimeiro < oSegundo {
//        return true
//    } else {
//        return false
//    }
//    // return oPrimeiro < oSegundo
//}
//
//print(eMenor(oPrimeiro: 3, oSegundo: 5))
//print(eMenor(oPrimeiro: 7, oSegundo: 5))
//print(eMenor(oPrimeiro: 10, oSegundo: 10))
//
//
//func lala() -> String {
//    return "outro lala"
//}
//
//print(lala())
//
//
//func impareMaiorQueDez(umNumero: Int) -> Bool {
//    if umNumero > 10 && umNumero % 2 > 0 {
//        return true
//    }
//    return false
//}
//
//print(impareMaiorQueDez(umNumero:12))


var arrayNames = [String]()
arrayNames.append("João")
arrayNames.append("Marcos")
arrayNames.append("Jessica")
arrayNames.append("Thiago")
arrayNames.append("Luiz")
arrayNames.append("Jorge")
arrayNames.append("Elias")


for index in 1...4 {
    print(index)
}

print("\n---\n")

let array = ["A","B","C","D"]

for letra in array {
    print(letra)
}



//
//
//let name = arrayNames[0]
//
//arrayNames[0] = "Rafael"
//
//
//var aurelio = [String: String]()
//
//aurelio["array"] = "Lista de dados"
//aurelio["dicionario"] = "Lista com chave e valor"
//
//print(aurelio["array"])


func correr() {
    print("💨")
}
correr()

func aprenderSwift() -> Bool {
    return true
}

let aprendeu = aprenderSwift()
print(aprendeu)

func somar(numero1: Int, numero2: Int) -> Int {
    let soma = numero1 + numero2
    return soma
}

let resultado = somar(numero1: 1, numero2: 2)


var arrayX = [String]()
arrayX.append("X")
arrayX.append("Y")
arrayX.append("Z")

var valorA = arrayX[0]
arrayX[0] = "LALALA"
print(valorA)
valorA = arrayX[0]


for i in 0..<arrayX.count {
    print("Indice \(i)")
}

for objeto in arrayX {
    print("Objeto: \(objeto)")
}



var dictionaryX = [String: Int]()
dictionaryX["joao"] = 10
dictionaryX["jose"] = 9

var dictionaryY = [Int: String]()
dictionaryY[25] = "marcos"
dictionaryY[100] = "jubileu"
